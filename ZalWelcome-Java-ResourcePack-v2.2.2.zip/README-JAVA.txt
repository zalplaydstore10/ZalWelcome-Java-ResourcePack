ZalWelcome Java Resource Pack v2.2.2

Target compatibility: Minecraft Java 1.21.1 through 1.21.11.
This is the single unified Java resource pack. It uses legacy metadata fields for clients
up to 1.21.8 and min_format/max_format for clients 1.21.9 through 1.21.11.

Contents:
- pack.mcmeta
- assets/zalwelcome/sounds.json
- assets/zalwelcome/sounds/*.ogg

Sound IDs:
- zalwelcome:welcome
- zalwelcome:fantasy
- Per-world IDs are generated automatically from discovered world audio.

The plugin generates the Java ZIP at:
plugins/ZalWelcome/resourcepack/ZalWelcome-Java-ResourcePack-v2.2.2.zip

Upload the ZIP unchanged to a direct HTTPS hosting URL, then update resourcepack.java-url
and resourcepack.java-sha1 in config.yml. After changing audio files, run /zalwelcome audio,
upload the newly generated ZIP, and update java-sha1.
