ZalWelcome Bedrock Resource Pack v2.2.2

This pack is separate from the Java Edition pack. Do not combine or rename the Java ZIP for Bedrock use.

Contents:
- manifest.json (resource pack manifest, version 2.2.2)
- sounds/sound_definitions.json
- sounds/custom/welcome.ogg
- sounds/custom/fantasy.ogg

Install the ZIP using the resource-pack workflow supported by your installed Geyser version. Keep the manifest at the root of the pack archive. Ensure the pack is enabled/required as appropriate for your server policy, then connect using a real Bedrock client to verify download and audio playback.

The plugin's diagnostics only detects whether Geyser/Floodgate is installed. It does not install, configure, host, or guarantee custom sound mapping for Geyser. Confirm that the installed Geyser version maps the Java sound identifiers zalwelcome:welcome and zalwelcome:fantasy to these Bedrock sound definitions.

Replace audio through plugins/ZalWelcome/audio/ and run /zalwelcome audio to regenerate the Bedrock ZIP.
