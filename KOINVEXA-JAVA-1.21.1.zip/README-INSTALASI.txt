KOINVEXA JAVA RESOURCE PACK
Target: Minecraft Java 1.21.1 (resource pack format 34)

INSTALL
1. Put KOINVEXA-JAVA-1.21.1.zip into the player's .minecraft/resourcepacks folder.
2. Enable it in Options > Resource Packs.
3. Every player who should see the custom glyphs must have this pack enabled.
4. For server delivery, host the ZIP on a direct-download HTTPS URL and configure server.properties resource-pack=... (and SHA-1 if desired).

TAB FONT
Font ID: koinvexa:default
Logo glyph: U+E200

MiniMessage examples for TAB (Paper supports MiniMessage):
title: "<font:koinvexa:default>\uE200</font>"
line icon example: "<font:koinvexa:default>\uE201</font> <#F4C542>Nama: <white>%player%"

GLYPH MAP
U+E200  KOINVEXA logo wordmark
U+E201  Crown
U+E202  Player
U+E203  Rank star
U+E204  Coin
U+E205  Globe
U+E206  Online / play
U+E207  Clock
U+E208  Website / chart
U+E209  Link
U+E20A  Gift

IMPORTANT
- This pack supplies custom fonts/glyphs. It does not itself create a scoreboard or a background panel.
- The font is namespaced as koinvexa:default. Use the MiniMessage font tag in TAB.
- If TAB's scoreboard title/lines are not parsed as MiniMessage in your current config, use the literal private-use characters from the glyph map in the included glyph list.
